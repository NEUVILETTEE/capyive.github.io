document.querySelector('.need-help').addEventListener('click', function() {
    alert('Redirecting to help page.');
});
